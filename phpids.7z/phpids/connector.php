<?php

class ssh2_connector {

private $username;
private $password;
private $port = 22;
private $file_prefix_path = "/var/www/html/playtika/cc_fb_en/php/config/";
private $idresult;

private $id;
private $filelist;
private $serverlist;

public $file_content_prefix;

// ID(s) arrays
public $find_response = array();

public $id_list_response  = array();
public $false_server_list = array();
public $false_file_list = array();

public function __construct($a, $b){
		$this->username = $a;
		$this->password = $b;
		}

public function setParameters($id, $serverlist, $filelist) {
		$this->id = $id;
		$this->filelist = $filelist;
		$this->serverlist = $serverlist;
		}
	
public function findClientId() { 
		foreach ($this->serverlist as $key1 => $val1) { 
	    foreach ($this->filelist as $key2 => $val2) { 
				foreach ($this->id as $id_var) {
						
				$ssh2 = ssh2_connect($val1, $this->port);
						
				if (ssh2_auth_password($ssh2, $this->username, $this->password)) {
										
				$stream = ssh2_exec($ssh2, "cat /var/www/html/playtika/cc_fb_en/php/config/".$val2." | grep ". $id_var ." | grep -o '[0-9]'* | head -1");
				stream_set_blocking($stream, true);
										
				$this->idresult = fread($stream, 4096);
										
				if ($this->idresult != null) {
						$this->find_response[] = '<span class="glyphicon glyphicon-ok" aria-hidden="true"></span> ID <strong>'.$this->idresult.' found</strong> on <em>'.$val1.'</em> in <em>'.$val2.'</em>.';
						fclose($stream);		
					
						} else {
						$this->find_response[] = '<span class="glyphicon glyphicon-remove" aria-hidden="true" style="color: #d43f3a"></span> No ID '.$id_var.' found on <em>'.$val1.'</em> in <em>'.$val2.'</em>.';
						fclose($stream);
						}
				} else {
					echo "Connection error.";
						}
				}
			}			
		}
				unset($ssh2);
		}

public function addClientId() {
		foreach ($this->serverlist as $key1 => $val1) {
			foreach ($this->filelist as $key2 => $val2) {
				foreach ($this->id as $id_var) {
				
				$ssh2 = ssh2_connect($val1, $this->port);				
						
				if (ssh2_auth_password($ssh2, $this->username, $this->password)) {
								
            $stream1 = ssh2_exec($ssh2, "cat /var/www/html/playtika/cc_fb_en/php/config/".$val2." | grep ". $id_var ." | grep -o '[0-9]'* | head -1");
            stream_set_blocking($stream1, true);
						
            $this->idresult = fread($stream1, 4096);
            fclose($stream1);
										
            $stream2 = ssh2_exec($ssh2, 'cat /var/www/html/playtika/cc_fb_en/php/config/'.$val2.' | awk -F \' [0-9]\' \'{ print $1 }\' | grep -v [0-9] | grep -vE "^;|^#" | tail -1');
            stream_set_blocking($stream2, true);
						
            $this->file_content_prefix = fread($stream2, 4096);
            fclose($stream2);
										
						if ($this->idresult != null) {
								
                } else {
                    $this->false_server_list[] = $val1;
                    $this->false_file_list[] = $val2;
										$this->id_list_response[] = $id_var;
														
                    $tmp = trim($this->file_content_prefix).trim($id_var);
                    ssh2_exec($ssh2, 'echo "'.$tmp.'" >> /var/www/html/playtika/cc_fb_en/php/config/'.$val2);
										
                }
				} else {
					echo "Connection error.";					
            }
				}
			}	
		}
    unset($ssh2);
}
				
public function getFoundClientId() {
		foreach ($this->find_response as $responce) {
		echo $responce.'<br>';
				}
		}
		
public function getAddedClientId() {
		foreach(array_combine($this->false_file_list, $this->false_server_list) as $list => $server) {
				foreach($this->id_list_response as $id_response){
				echo 'ID <strong>'.$id_response.'</strong> was successfully added on <em>'.$server.'</em> to list: <strong>'.$list.'</strong><br>';
						}
				}
		}
	
public function __destruct() {
		unset($this->username);
		unset($this->password);
	}

	
}

?>