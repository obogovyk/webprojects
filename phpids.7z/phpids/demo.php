<?php

error_reporting(E_ALL);
ini_set('display_errors', '1');

?>

<!DOCTYPE html>
<html lang="utf-8">
<head>
		
</head>		

<body>

<p>Result goes down: </p>
		<hr>

<?php

$id_arr = array();

if(isset($_POST['ids'])) {
		
		$id_arr = explode(" ", preg_replace('/[\^a-zA-Z\"\'\.\,\;\%\$\&\*\!\?\#\/n\r]/', " ", $_POST['ids']));
		//$id_arr = explode(", ", htmlspecialchars(preg_replace('/[\" "\","\/n\r]/', ", ", preg_replace('/[\^a-zA-Z\"\'\.\;\%\$\&\*\!\?\#]/', "", $_POST['ids']))));
		//echo htmlspecialchars(preg_replace('/\s+/', ",", preg_replace('/[\^a-zA-Z\"\'\;\%\$\&\*\!\?\#]/', "", $_POST['ids'])))."<br>";
		}

		print_r($id_arr);
		
?>

		<br>
<form action="" method="POST" accept-charset="UTF-8">
		<textarea name="ids" id="" placeholder="100003837371453" rows="5" cols="50"></textarea><br>
		<input type="submit" name="submit" value="Submit">
</form>
		
		
</body>		
</html>

