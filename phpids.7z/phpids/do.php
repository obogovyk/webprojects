<?php
require_once("connector.php");

$ids_arr = explode(" ", preg_replace('/[\^a-zA-Z\"\'\.\,\;\%\$\&\*\!\?\#\s\s+]/', " ", $_POST['ids_data']));

switch($_POST['action']){
    case 'add':
        $conn = new ssh2_connector("root","abudfvf");        
        $conn->setParameters($ids_arr,$_POST['serverList'],$_POST['fileList']);
        $conn->addClientId();
        $response = $conn->getAddedClientId();
        break;
    case 'find':
        $conn = new ssh2_connector("root","abudfvf");
        $conn->setParameters($ids_arr,$_POST['serverList'],$_POST['fileList']);
        $conn->findClientId();
        $response = $conn->getFoundClientId();
        break;
    default:
        $response = 'Not found method "'.$_POST['action'].'"';
}
header('Content-Type: application/json');
$json = json_encode($data);
return $json;