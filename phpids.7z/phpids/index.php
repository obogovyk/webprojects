<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once("lists.php");
require_once("serverList.php");
?>

<!DOCTYPE html>
<html lang="us">
<head>
    <title>Configuration List Utility</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script src="http://code.jquery.com/ui/1.11.2/jquery-ui.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom-devs.js"></script>
        
</head>
<body>

<div class="container">
    <div class="row" style="margin-top: 30px">
        <div class="col-md-6">
            <p style="font-style: italic">User ID(s): </p>
            <textarea id="ids-area" name="ids_data" class="form-control" placeholder="100003837371453" rows="5" required="required" style="resize: vertical;"></textarea>
                <p><div class="alert alert-danger" id="digit-alert" style="display: none"><strong>Error!</strong> Only digits allowed.</div></p>
                
            <div id="configList">
            <?php foreach($config_list as $clk => $clv) :?>
            <div class="checkbox">
                <label>
                    <p><input type="checkbox" name="fileList[]" value="<?php echo $clk; ?>" id="<?php echo $clk; ?>"> <?php echo $clv; ?></p>
                </label>
            </div>
            <?php endforeach; ?>
            </div>
            <button type="button" name="add" class="btn btn-success" id="btn-add"><span class="glyphicon glyphicon-plus"></span> Add ID</button>
            <button type="button" name="clear" class="btn btn-danger" id="btn-clear""><span class="glyphicon glyphicon-erase"></span> Clear</button>
            <button type="button" name="find" class="btn btn-default pull-right" id="btn-find"><span class="glyphicon glyphicon-search"></span> Find ID</button>
        
        </div>
        
        <div class="col-md-6">
            <p><em>Server List:</em><span class="pull-right"><span class="label label-primary pull-right chkAll" style="cursor: pointer; width: 75px;" prop="true">Select All</span></p>
            <div class="list-group" id="serverList">
            <?php
                foreach ($server_list as $slk => $slv) {
                    if ($slk == "stage") {
                        echo '<div class="list-group-item"><em><strong>Stage Servers</strong></em></div>';
                    }
                    else{
                        echo '<div class="list-group-item"><em><strong>Developer Servers</strong></em></div>';
                    }
                    foreach($slv as $name => $ip) {
                        echo '<div class="list-group-item"><em><input type="checkbox" name="serverList[]" value="'.$ip.'" id="'.$name.'"> '.$name.'<span class="pull-right" style="color: #959595">'.$ip.'</span></em></div>';
                    }
                }
            ?>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="modal-dialog" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <em><h4 class="modal-title" id="modal-title"></h4></em>
                </div>    
                <div class="modal-body">
                    <p id="modal-body"></p>
                </div>        
                <div class="modal-footer">
                    <a class="pull-left" href="http://findmyfacebookid.com" target="blank_"><em> Find Facebook ID</em></a>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>    
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    
</div>

</body>
</html>
