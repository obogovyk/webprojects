$(document).ready(function(){
    
    $('#ids-area').keypress(function (e) {
    if (e.which != 8 && e.which != 0 && e.which != 32 && (e.which > 57)) {
        $('#digit-alert').css({display: "block"}).fadeOut(2000);
            return false;
        }
    });

    
    $('#btn-find').click(function(){
        if(checkData()){
            sendData($(this).attr('name'));
        }
    });

    $('#btn-add').click(function(){
        if(checkData()){
            sendData( $(this).attr('name') );
        }
    });

    function checkData(){
        if( $('#ids-area').val() == '' ){
            
            $('#modal-title').html('<span class="glyphicon glyphicon-warning-sign" aria-hidden="true"></span> Warning');
            $('#modal-body').html('<strong>No ID found.</strong><br>Please enter your <em>Facebook ID</em> before submission.');
            
            $("#modal-dialog").modal("show");
            return false;
        }
       
        if( $('#configList :checked').length == 0 ){
            
            $('#modal-title').html('<span class="glyphicon glyphicon-warning-sign" aria-hidden="true"></span> Warning');
            $('#modal-body').html('<strong>No configuration list selected.</strong><br>Please select <em>one or multiply</em> configuration list(s) before submission.');
            
            $("#modal-dialog").modal("show");
            return false;
        }
        
        if( $('#serverList :checked').length == 0 ){
            
            $('#modal-title').html('<span class="glyphicon glyphicon-warning-sign" aria-hidden="true"></span> Warning');
            $('#modal-body').html('<strong>No server list selected.</strong><br>Please select <em>one or multiply</em> server(s) before submission.');
            
            $("#modal-dialog").modal("show");
            return false;
        }
        
        return true;
    }

    function sendData(action){
        var serverList = [];
        var configList = [];
        $('#serverList :checked').each(function(i){
            serverList.push($(this).val());
        });
        $('#configList :checked').each(function(i){
            configList.push($(this).val());
        });
        
        var id = $('#ids-area').val();
        $.ajax({
            async: true,
            dataType: 'json',
            type: 'POST',
            url: 'do.php',
            data: {
                ids_data: id,
                serverList: serverList,
                fileList: configList,
                action: action
            },
            
            success: function(textStatus, data){
                //$( "#dialog" ).html(data).dialog( "option", { title: textStatus }).dialog("open");
                $('#modal-title').html('<span class="glyphicon glyphicon-ok"></span> Information');//+textStatus);
                $('#modal-body').html(data);
                 
                $("#modal-dialog").modal("show");
            },
            
            error: function(XMLHttpRequest, textStatus, errorThrown){
                //$( "#dialog").html(XMLHttpRequest.responseText).dialog( "option", { title: textStatus }).dialog( "open" );
                $('#modal-title').html('<span class="glyphicon glyphicon-warning-sign"></span> Information');//+textStatus);
                $('#modal-body').html(XMLHttpRequest.responseText);
                
                $("#modal-dialog").modal("show");
            }
        });
    }

    $('.chkAll').click(function(){
        if( $(this).attr('prop') == 'true' ) {
            $.each( $('#serverList :checkbox' ), function(){
                this.checked = true;
            });
            
            $(this).attr('prop', 'false').text('Deselect all');
        }
        
        else{
            $('#serverList :checkbox').removeAttr('checked');
            $(this).attr('prop', 'true').text('Select all');
        }
        
    });
    
    
    // Old Dialog Window //
    //    $('#dialog').dialog({
    //    closeOnEscape: false,
    //    autoOpen: false,
    //    buttons: [
    //        {
    //            text: "OK",
    //            icons: {
    //                primary: "ui-icon-heart"
    //            },
    //            click: function() {
    //                $(this).dialog( "close" );
    //            }
    //        }
    //    ],
    //    draggable: true,
    //    height: 200,
    //    width: 400,
    //    modal: true
    //});
    // -- END -- //
    
    
 });

