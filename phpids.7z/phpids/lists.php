<?php

$config_list = array(
  "black_list.ini"				=>"Black List <br><em style=\"font-style: italic; color: grey\">Add User to Facebook 'Black List' (*.ini).</em>",
  "fb_beta_mode_list.ini"	=>"Beta Mode List <br><em style=\"font-style: italic; color: grey\">Add User to Beta Mode List (*.ini).</em>",
  "developers_list.ini"		=>"Developers List <br><em style=\"font-style: italic; color: grey\">Add User to Developers List (*.ini).</em>",
	
);

	
?>