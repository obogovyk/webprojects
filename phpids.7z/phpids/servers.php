<?php

$server_list = array(
"stage-srv"				=>"Stage Servers",
//"10.200.74.112"  	=>"CC stage 12",
//"10.200.74.141" 	=>"CC stage 13",
"10.32.40.230"		=>"Stage-dp-a <span class=\"pull-right\" style=\"color: #959595\">10.32.40.230</span>",
"10.32.40.232"		=>"Stage-dp-b <span class=\"pull-right\" style=\"color: #959595\">10.32.40.232</span>",
"10.32.40.238"		=>"Stage-dp-c <span class=\"pull-right\" style=\"color: #959595\">10.32.40.238</span>",
"10.32.40.216"		=>"Stage-dp-d <span class=\"pull-right\" style=\"color: #959595\">10.32.40.216</span>",
"dev-srv"					=>"Developer Servers",
"10.32.40.222"		=>"Dev-dp-b <span class=\"pull-right\" style=\"color: #959595\">10.32.40.222</span>",
"10.32.40.224"		=>"Dev-dp-c <span class=\"pull-right\" style=\"color: #959595\">10.32.40.224</span>",
"10.32.40.220"		=>"Dev-dp-a <span class=\"pull-right\" style=\"color: #959595\">10.32.40.220</span>",
"10.32.40.226"		=>"Dev-dp-d <span class=\"pull-right\" style=\"color: #959595\">10.32.40.226</span>",
"10.32.40.234"		=>"Dev-dp-e <span class=\"pull-right\" style=\"color: #959595\">10.32.40.234</span>",
"10.32.40.236"		=>"Dev-dp-f <span class=\"pull-right\" style=\"color: #959595\">10.32.40.236</span>",
"10.32.40.228"		=>"Dev-dp-g <span class=\"pull-right\" style=\"color: #959595\">10.32.40.228</span>",
"10.32.40.218"		=>"Dev-dp-h <span class=\"pull-right\" style=\"color: #959595\">10.32.40.218</span>",
"10.32.40.120"		=>"Dev-dp-j <span class=\"pull-right\" style=\"color: #959595\">10.32.40.120</span>",
"10.32.40.122"		=>"Dev-dp-k <span class=\"pull-right\" style=\"color: #959595\">10.32.40.122</span>",
"10.32.40.124"		=>"Dev-dp-l <span class=\"pull-right\" style=\"color: #959595\">10.32.40.124</span>"

 );

?>